import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sklearn.pipeline import Pipeline
import joblib
# Assuming you have a CSV file named 'emotion_dataset.csv'
df = pd.read_csv('emotiondataset.csv')

# Separate features and labels
X = df['Text']
y = df['Emotion']
# Define the pipeline with TfidfVectorizer and LinearSVC
model = Pipeline([
    ('tfidf', TfidfVectorizer()),  # You can customize the vectorizer parameters here
    ('clf', LinearSVC(random_state=123, max_iter=8000)),
])

# Train the model
model.fit(X, y)
# Save the model
emoji_dict = {"joy":"😂", "fear":"😨", "anger":"😠", "sadness":"😥", "disgust":"😒",
"shame":"😳", "surprise":"😧","neutral":"😐"}

joblib.dump(model, 'emotion_classification_model.pkl')

# Save the vectorizer for later use during deployment
vectorizer = model.named_steps['tfidf']
joblib.dump(vectorizer, 'text_vectorizer.pkl')
