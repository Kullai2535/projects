from flask import Flask, render_template, request, jsonify
import joblib

app = Flask(__name__)

# Load the model and vectorizer
model = joblib.load('emotion_classification_model.pkl')
vectorizer = joblib.load('text_vectorizer.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        text = request.form['text']

        # Preprocess the input text
        features = vectorizer.transform([text])

        # Make predictions
        prediction = model.predict(features)

        return render_template('result.html', text=text, emotion=prediction[0])

if __name__ == '__main__':
    app.run(port=5000, debug=True)
